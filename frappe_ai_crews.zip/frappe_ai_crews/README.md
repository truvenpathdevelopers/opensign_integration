# Frappe AI Crews

A comprehensive Frappe/ERPNext app that integrates CrewAI multi-agent AI systems for HR and Knowledge Management.

## Features

### 🎯 Job Posting Generator
AI-powered job description creation with 4 specialized agents:
- **Research Analyst**: Researches company culture and values
- **Industry Expert**: Analyzes role requirements and market trends
- **Job Writer**: Creates compelling job posting content
- **Compliance Reviewer**: Ensures legal compliance and quality

### 👥 Recruitment Assistant
Automated candidate sourcing and evaluation:
- **Talent Sourcer**: Finds potential candidates
- **Candidate Screener**: Screens against requirements
- **Candidate Evaluator**: In-depth evaluation
- **Recruitment Strategist**: Creates outreach strategies

### 📊 Profile Matcher
CV-to-Job matching with detailed compatibility analysis:
- **CV Parser**: Extracts structured data from resumes
- **Job Analyzer**: Analyzes job requirements
- **Match Scorer**: Scores and analyzes compatibility
- **Recommendation Writer**: Generates actionable recommendations

### 📚 Knowledge Base Q&A
PDF-based Q&A system using RAG (Retrieval Augmented Generation):
- **Knowledge Retriever**: Searches the knowledge base
- **Context Analyzer**: Analyzes retrieved documents
- **Answer Synthesizer**: Creates comprehensive answers
- **Answer Reviewer**: Reviews for accuracy and quality

## Installation

### Prerequisites
- Frappe/ERPNext v14 or v15
- Python 3.10 - 3.12
- OpenAI API key (required)
- Serper API key (optional, for web search)

### Install the App

```bash
# Get the app
cd ~/frappe-bench
bench get-app https://github.com/your-repo/frappe_ai_crews.git

# Install on your site
bench --site your-site install-app frappe_ai_crews

# Install Python dependencies
pip install crewai crewai-tools langchain langchain-community chromadb pypdf

# Run migrations
bench --site your-site migrate

# Build assets
bench build

# Restart
bench restart
```

## Configuration

### 1. Set up API Keys

Go to **AI Crew Settings** and configure:

| Setting | Required | Description |
|---------|----------|-------------|
| OpenAI API Key | Yes | Your OpenAI API key (starts with sk-) |
| Model | Yes | AI model to use (default: gpt-4o) |
| Serper API Key | No | For web search capabilities |
| Anthropic API Key | No | For Claude models |

### 2. Verify Installation

Check if everything is working:

```javascript
// In browser console or server script
frappe.call({
    method: "frappe_ai_crews.api.check_ai_status",
    callback: function(r) {
        console.log(r.message);
    }
});
```

## Usage

### Job Posting Generator

1. Go to **Job Posting Request** > New
2. Fill in company name, job title, and industry
3. Add optional details (requirements, salary, location)
4. Click **Generate Job Posting**
5. Wait for AI to generate the posting (2-5 minutes)

```python
# API Usage
import frappe

result = frappe.call(
    "frappe_ai_crews.api.generate_job_posting",
    company_name="Acme Corp",
    job_title="Senior Python Developer",
    industry="Technology",
    requirements="5+ years Python experience",
    salary_range="$120,000 - $150,000"
)
```

### Recruitment Assistant

1. Go to **Recruitment Request** > New
2. Fill in job details and requirements
3. Add company information and value proposition
4. Click **Run Recruitment**
5. Review the sourced and evaluated candidates

### Profile Matcher

1. Go to **Profile Match Request** > New
2. Upload or paste CV content
3. Paste the job description
4. Click **Analyze Match**
5. Review match score and recommendations

### Knowledge Base

1. Create a **Knowledge Base**
2. Add PDF documents
3. Click **Rebuild Index**
4. Go to **Knowledge Query** to ask questions

## API Reference

### Job Posting
```python
frappe_ai_crews.api.generate_job_posting(
    company_name, job_title, industry,
    requirements="", salary_range="", 
    work_location="Office", employment_type="Full-time"
)
```

### Recruitment
```python
frappe_ai_crews.api.run_recruitment(
    company_name, job_title, industry, requirements,
    must_have_skills="", nice_to_have_skills="",
    experience_level="Mid-level"
)
```

### Profile Matching
```python
frappe_ai_crews.api.match_profile_to_job(
    cv_content, job_title, company_name, job_description
)
```

### Knowledge Base
```python
# Create knowledge base
frappe_ai_crews.api.create_knowledge_base(name, description)

# Add documents
frappe_ai_crews.api.add_documents_to_kb(kb_name, file_urls)

# Query
frappe_ai_crews.api.query_knowledge_base(question, knowledge_base_name)
```

## DocTypes

| DocType | Description |
|---------|-------------|
| AI Crew Settings | Single DocType for API configuration |
| Job Posting Request | Job posting generation requests |
| Recruitment Request | Recruitment process requests |
| Profile Match Request | CV-Job matching requests |
| Knowledge Base | Document collections for Q&A |
| Knowledge Query | Questions to knowledge bases |

## Troubleshooting

### Common Issues

**"CrewAI not installed"**
```bash
pip install crewai crewai-tools --break-system-packages
```

**"OpenAI API key not configured"**
Go to AI Crew Settings and add your API key.

**"RAG dependencies not installed"**
```bash
pip install langchain langchain-community chromadb
```

**Slow responses**
- CrewAI operations take 2-10 minutes depending on complexity
- Operations run as background jobs
- Check Error Log for issues

## Based On

This app is based on the official CrewAI examples:
- [Job Posting](https://github.com/crewAIInc/crewAI-examples/tree/main/crews/job-posting)
- [Recruitment](https://github.com/crewAIInc/crewAI-examples/tree/main/crews/recruitment)
- [Match Profile to Positions](https://github.com/crewAIInc/crewAI-examples/tree/main/crews/match_profile_to_positions)
- [Meta Quest Knowledge](https://github.com/crewAIInc/crewAI-examples/tree/main/crews/meta_quest_knowledge)

## License

MIT License

## Support

For issues and feature requests, please create an issue on GitHub.
