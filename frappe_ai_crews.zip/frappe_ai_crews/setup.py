from setuptools import setup, find_packages

setup(
    name='frappe_ai_crews',
    version='1.0.0',
    description='CrewAI Multi-Agent HR & Knowledge Management for Frappe/ERPNext',
    author='Your Company',
    author_email='info@yourcompany.com',
    packages=find_packages(),
    zip_safe=False,
    include_package_data=True,
    install_requires=[
        'frappe',
    ]
)
