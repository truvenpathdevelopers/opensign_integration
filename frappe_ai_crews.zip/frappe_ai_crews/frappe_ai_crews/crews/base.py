"""
Base Crew Class - Common functionality for all crews
"""

import os
import yaml
import frappe
from frappe import _
from typing import Dict, Any, List, Optional
from abc import ABC, abstractmethod

# CrewAI imports
try:
    from crewai import Agent, Crew, Process, Task
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    Agent = None
    Crew = None
    Process = None
    Task = None

# Tools imports
try:
    from crewai_tools import SerperDevTool, WebsiteSearchTool, PDFSearchTool
    TOOLS_AVAILABLE = True
except ImportError:
    TOOLS_AVAILABLE = False


class BaseCrew(ABC):
    """
    Base class for all CrewAI crews in the Frappe app.
    
    Provides common functionality for loading configurations,
    creating agents and tasks, and running crews.
    """
    
    crew_name: str = "base"
    
    def __init__(self, inputs: Dict[str, Any]):
        """
        Initialize the crew with inputs.
        
        Args:
            inputs: Dictionary of input variables for the crew
        """
        if not CREWAI_AVAILABLE:
            frappe.throw(_("CrewAI is not installed. Please run: pip install crewai crewai-tools"))
        
        self.inputs = inputs
        self.agents_config = self._load_config("agents.yaml")
        self.tasks_config = self._load_config("tasks.yaml")
        self._setup_environment()
    
    def _load_config(self, filename: str) -> Dict:
        """Load a YAML configuration file for this crew."""
        app_path = frappe.get_app_path("frappe_ai_crews")
        config_path = os.path.join(app_path, "config", self.crew_name, filename)
        
        if not os.path.exists(config_path):
            frappe.throw(_(f"Configuration file not found: {config_path}"))
        
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def _setup_environment(self):
        """Set up environment variables from settings."""
        try:
            settings = frappe.get_single("AI Crew Settings")
            
            if settings.openai_api_key:
                os.environ["OPENAI_API_KEY"] = settings.get_password("openai_api_key")
            
            if settings.serper_api_key:
                os.environ["SERPER_API_KEY"] = settings.get_password("serper_api_key")
            
            self.model = settings.model or "gpt-4o"
            self.verbose = settings.verbose_logging
            
        except Exception as e:
            frappe.log_error(f"Error loading AI Crew Settings: {e}")
            self.model = "gpt-4o"
            self.verbose = True
    
    def _format_string(self, text: str) -> str:
        """Format a string with input variables."""
        try:
            return text.format(**self.inputs)
        except KeyError as e:
            # If a variable is missing, return original text
            return text
    
    def _format_config(self, config: Dict) -> Dict:
        """Format all strings in a config dict with inputs."""
        formatted = {}
        for key, value in config.items():
            if isinstance(value, str):
                formatted[key] = self._format_string(value)
            elif isinstance(value, dict):
                formatted[key] = self._format_config(value)
            elif isinstance(value, list):
                formatted[key] = [
                    self._format_string(v) if isinstance(v, str) else v 
                    for v in value
                ]
            else:
                formatted[key] = value
        return formatted
    
    def _get_tools(self, agent_name: str) -> List:
        """Get tools for a specific agent. Override in subclasses."""
        tools = []
        if TOOLS_AVAILABLE:
            if hasattr(self, 'serper_api_key') and self.serper_api_key:
                tools.append(SerperDevTool())
        return tools
    
    def _create_agent(self, agent_name: str) -> Agent:
        """Create an agent from configuration."""
        if agent_name not in self.agents_config:
            frappe.throw(_(f"Agent '{agent_name}' not found in configuration"))
        
        config = self._format_config(self.agents_config[agent_name])
        tools = self._get_tools(agent_name)
        
        return Agent(
            role=config.get("role", ""),
            goal=config.get("goal", ""),
            backstory=config.get("backstory", ""),
            verbose=config.get("verbose", self.verbose),
            allow_delegation=config.get("allow_delegation", False),
            tools=tools,
            llm=self.model
        )
    
    def _create_task(
        self, 
        task_name: str, 
        agent: Agent, 
        context_tasks: List[Task] = None
    ) -> Task:
        """Create a task from configuration."""
        if task_name not in self.tasks_config:
            frappe.throw(_(f"Task '{task_name}' not found in configuration"))
        
        config = self._format_config(self.tasks_config[task_name])
        
        return Task(
            description=config.get("description", ""),
            expected_output=config.get("expected_output", ""),
            agent=agent,
            context=context_tasks or []
        )
    
    @abstractmethod
    def _build_crew(self) -> Crew:
        """Build and return the crew. Must be implemented by subclasses."""
        pass
    
    def run(self) -> str:
        """
        Execute the crew and return the result.
        
        Returns:
            The final output from the crew execution.
        """
        if not os.environ.get("OPENAI_API_KEY"):
            frappe.throw(_("OpenAI API key not configured. Please set it in AI Crew Settings."))
        
        crew = self._build_crew()
        result = crew.kickoff()
        
        # Handle different result types
        if hasattr(result, 'raw'):
            return result.raw
        elif hasattr(result, 'output'):
            return result.output
        else:
            return str(result)
    
    def run_async(self, callback_doctype: str = None, callback_name: str = None):
        """
        Queue crew execution as a background job.
        
        Args:
            callback_doctype: DocType to update with results
            callback_name: Document name to update
        """
        from frappe.utils.background_jobs import enqueue
        
        enqueue(
            "frappe_ai_crews.crews.utils.run_crew_background",
            crew_class=self.__class__.__name__,
            inputs=self.inputs,
            callback_doctype=callback_doctype,
            callback_name=callback_name,
            queue="long",
            timeout=900  # 15 minutes
        )
