"""
Job Posting Crew - AI-powered job description generation
Based on: https://github.com/crewAIInc/crewAI-examples/tree/main/crews/job-posting
"""

import frappe
from frappe import _
from typing import Dict, Any
from frappe_ai_crews.crews.base import BaseCrew, CREWAI_AVAILABLE

if CREWAI_AVAILABLE:
    from crewai import Crew, Process


class JobPostingCrew(BaseCrew):
    """
    Crew for generating comprehensive job postings.
    
    Agents:
    - Research Analyst: Researches company culture and values
    - Industry Expert: Analyzes role requirements and market trends
    - Job Writer: Creates compelling job posting content
    - Compliance Reviewer: Ensures legal compliance and quality
    """
    
    crew_name = "job_posting"
    
    def _get_tools(self, agent_name: str):
        """Get tools for job posting agents."""
        tools = []
        try:
            from crewai_tools import SerperDevTool, WebsiteSearchTool
            if agent_name in ["research_analyst", "industry_expert"]:
                if hasattr(self, 'serper_api_key'):
                    tools.append(SerperDevTool())
                tools.append(WebsiteSearchTool())
        except ImportError:
            pass
        return tools
    
    def _build_crew(self) -> 'Crew':
        """Build the job posting crew."""
        # Create agents
        research_analyst = self._create_agent("research_analyst")
        industry_expert = self._create_agent("industry_expert")
        job_writer = self._create_agent("job_writer")
        compliance_reviewer = self._create_agent("compliance_reviewer")
        
        # Create tasks with dependencies
        research_task = self._create_task("research_company", research_analyst)
        analyze_task = self._create_task("analyze_role", industry_expert)
        write_task = self._create_task("write_posting", job_writer, [research_task, analyze_task])
        review_task = self._create_task("review_posting", compliance_reviewer, [write_task])
        
        # Build crew
        return Crew(
            agents=[research_analyst, industry_expert, job_writer, compliance_reviewer],
            tasks=[research_task, analyze_task, write_task, review_task],
            process=Process.sequential,
            verbose=self.verbose
        )


# =============================================================================
# FRAPPE API METHODS
# =============================================================================

@frappe.whitelist()
def generate_job_posting(
    company_name: str,
    job_title: str,
    industry: str,
    requirements: str = "",
    salary_range: str = "Competitive",
    work_location: str = "Office",
    employment_type: str = "Full-time",
    department: str = "",
    reports_to: str = ""
) -> Dict[str, Any]:
    """
    Generate a job posting using CrewAI.
    
    Args:
        company_name: Name of the hiring company
        job_title: Title of the position
        industry: Industry sector
        requirements: Specific job requirements
        salary_range: Salary range or "Competitive"
        work_location: Office/Remote/Hybrid
        employment_type: Full-time/Part-time/Contract
        department: Department name
        reports_to: Manager title
    
    Returns:
        Dictionary with generated job posting
    """
    inputs = {
        "company_name": company_name,
        "job_title": job_title,
        "industry": industry,
        "requirements": requirements or "Not specified",
        "salary_range": salary_range or "Competitive",
        "work_location": work_location or "Office",
        "employment_type": employment_type or "Full-time",
        "department": department or "Not specified",
        "reports_to": reports_to or "Hiring Manager"
    }
    
    try:
        crew = JobPostingCrew(inputs)
        result = crew.run()
        
        return {
            "success": True,
            "job_posting": result,
            "inputs": inputs
        }
    except Exception as e:
        frappe.log_error(f"Job Posting Generation Error: {str(e)}", "AI Crews")
        return {
            "success": False,
            "error": str(e)
        }


@frappe.whitelist()
def generate_job_posting_async(request_name: str) -> Dict[str, str]:
    """
    Queue job posting generation as background job.
    
    Args:
        request_name: Name of the Job Posting Request document
    
    Returns:
        Dictionary with job status
    """
    from frappe.utils.background_jobs import enqueue
    
    doc = frappe.get_doc("Job Posting Request", request_name)
    doc.status = "Processing"
    doc.save(ignore_permissions=True)
    frappe.db.commit()
    
    enqueue(
        "frappe_ai_crews.crews.job_posting.process_job_posting_request",
        request_name=request_name,
        queue="long",
        timeout=600
    )
    
    return {
        "success": True,
        "message": _("Job posting generation has been queued.")
    }


def process_job_posting_request(request_name: str):
    """Background job handler for job posting generation."""
    try:
        doc = frappe.get_doc("Job Posting Request", request_name)
        
        inputs = {
            "company_name": doc.company_name,
            "job_title": doc.job_title,
            "industry": doc.industry,
            "requirements": doc.requirements or "Not specified",
            "salary_range": doc.salary_range or "Competitive",
            "work_location": doc.work_location or "Office",
            "employment_type": doc.employment_type or "Full-time",
            "department": doc.department or "Not specified",
            "reports_to": doc.reports_to or "Hiring Manager"
        }
        
        crew = JobPostingCrew(inputs)
        result = crew.run()
        
        doc.status = "Completed"
        doc.generated_posting = result
        doc.save(ignore_permissions=True)
        frappe.db.commit()
        
        # Send notification
        frappe.publish_realtime(
            "job_posting_complete",
            {"request_name": request_name, "success": True},
            user=doc.owner
        )
        
    except Exception as e:
        frappe.log_error(f"Job Posting Error: {str(e)}", "AI Crews")
        
        doc = frappe.get_doc("Job Posting Request", request_name)
        doc.status = "Error"
        doc.error_message = str(e)
        doc.save(ignore_permissions=True)
        frappe.db.commit()
        
        frappe.publish_realtime(
            "job_posting_complete",
            {"request_name": request_name, "success": False, "error": str(e)},
            user=doc.owner
        )


def on_request_insert(doc, method):
    """Hook called when Job Posting Request is created."""
    if doc.auto_generate:
        generate_job_posting_async(doc.name)
