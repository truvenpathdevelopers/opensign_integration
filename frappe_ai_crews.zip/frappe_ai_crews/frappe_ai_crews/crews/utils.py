"""
Utility functions for Frappe AI Crews
"""

import frappe
from frappe import _
from typing import Dict, Any


def run_crew_background(
    crew_class: str,
    inputs: Dict[str, Any],
    callback_doctype: str = None,
    callback_name: str = None
):
    """
    Background job handler for running crews.
    
    Args:
        crew_class: Name of the crew class
        inputs: Input dictionary for the crew
        callback_doctype: DocType to update with results
        callback_name: Document name to update
    """
    from frappe_ai_crews.crews import (
        JobPostingCrew,
        RecruitmentCrew,
        MatchProfileCrew,
        MetaQuestCrew
    )
    
    crew_classes = {
        "JobPostingCrew": JobPostingCrew,
        "RecruitmentCrew": RecruitmentCrew,
        "MatchProfileCrew": MatchProfileCrew,
        "MetaQuestCrew": MetaQuestCrew
    }
    
    try:
        CrewClass = crew_classes.get(crew_class)
        if not CrewClass:
            raise ValueError(f"Unknown crew class: {crew_class}")
        
        crew = CrewClass(inputs)
        result = crew.run()
        
        if callback_doctype and callback_name:
            doc = frappe.get_doc(callback_doctype, callback_name)
            doc.status = "Completed"
            doc.result = result
            doc.save(ignore_permissions=True)
            frappe.db.commit()
            
            frappe.publish_realtime(
                "crew_complete",
                {
                    "doctype": callback_doctype,
                    "name": callback_name,
                    "success": True
                },
                user=doc.owner
            )
        
        return result
        
    except Exception as e:
        frappe.log_error(f"Crew Background Error: {str(e)}", "AI Crews")
        
        if callback_doctype and callback_name:
            doc = frappe.get_doc(callback_doctype, callback_name)
            doc.status = "Error"
            doc.error_message = str(e)
            doc.save(ignore_permissions=True)
            frappe.db.commit()
            
            frappe.publish_realtime(
                "crew_complete",
                {
                    "doctype": callback_doctype,
                    "name": callback_name,
                    "success": False,
                    "error": str(e)
                },
                user=doc.owner
            )
        
        raise


def process_pending_requests():
    """
    Scheduled task to process any pending requests.
    Runs hourly via hooks.py scheduler_events.
    """
    # Process pending Job Posting Requests
    pending_job_postings = frappe.get_all(
        "Job Posting Request",
        filters={"status": "Pending", "auto_generate": 1},
        pluck="name"
    )
    
    for name in pending_job_postings:
        try:
            from frappe_ai_crews.crews.job_posting import generate_job_posting_async
            generate_job_posting_async(name)
        except Exception as e:
            frappe.log_error(f"Error processing job posting {name}: {str(e)}", "AI Crews")
    
    # Process pending Recruitment Requests
    pending_recruitment = frappe.get_all(
        "Recruitment Request",
        filters={"status": "Pending", "auto_process": 1},
        pluck="name"
    )
    
    for name in pending_recruitment:
        try:
            from frappe_ai_crews.crews.recruitment import run_recruitment_async
            run_recruitment_async(name)
        except Exception as e:
            frappe.log_error(f"Error processing recruitment {name}: {str(e)}", "AI Crews")
    
    # Process pending Profile Match Requests
    pending_matches = frappe.get_all(
        "Profile Match Request",
        filters={"status": "Pending", "auto_process": 1},
        pluck="name"
    )
    
    for name in pending_matches:
        try:
            from frappe_ai_crews.crews.match_profile import match_profile_async
            match_profile_async(name)
        except Exception as e:
            frappe.log_error(f"Error processing profile match {name}: {str(e)}", "AI Crews")
    
    # Process pending Knowledge Queries
    pending_queries = frappe.get_all(
        "Knowledge Query",
        filters={"status": "Pending", "auto_process": 1},
        pluck="name"
    )
    
    for name in pending_queries:
        try:
            from frappe_ai_crews.crews.meta_quest import query_knowledge_async
            query_knowledge_async(name)
        except Exception as e:
            frappe.log_error(f"Error processing knowledge query {name}: {str(e)}", "AI Crews")


@frappe.whitelist()
def check_ai_status() -> Dict[str, Any]:
    """Check if AI Crews is properly configured and available."""
    import os
    
    status = {
        "crewai_installed": False,
        "tools_installed": False,
        "rag_available": False,
        "openai_configured": False,
        "serper_configured": False,
        "ready": False
    }
    
    # Check CrewAI
    try:
        import crewai
        status["crewai_installed"] = True
    except ImportError:
        pass
    
    # Check tools
    try:
        import crewai_tools
        status["tools_installed"] = True
    except ImportError:
        pass
    
    # Check RAG dependencies
    try:
        import langchain
        import chromadb
        status["rag_available"] = True
    except ImportError:
        pass
    
    # Check settings
    if frappe.db.exists("DocType", "AI Crew Settings"):
        try:
            settings = frappe.get_single("AI Crew Settings")
            status["openai_configured"] = bool(settings.openai_api_key)
            status["serper_configured"] = bool(settings.serper_api_key)
        except:
            pass
    
    # Overall readiness
    status["ready"] = (
        status["crewai_installed"] and 
        status["openai_configured"]
    )
    
    return status


@frappe.whitelist()
def get_available_crews() -> Dict[str, Any]:
    """Get list of available crews and their descriptions."""
    return {
        "crews": [
            {
                "name": "job_posting",
                "title": "Job Posting Generator",
                "description": "Generate comprehensive job postings with AI-powered research and writing",
                "agents": ["Research Analyst", "Industry Expert", "Job Writer", "Compliance Reviewer"]
            },
            {
                "name": "recruitment",
                "title": "Recruitment Assistant",
                "description": "Source, screen, and evaluate candidates with AI-powered analysis",
                "agents": ["Talent Sourcer", "Candidate Screener", "Candidate Evaluator", "Recruitment Strategist"]
            },
            {
                "name": "match_profile",
                "title": "Profile Matcher",
                "description": "Match candidate profiles to job positions with detailed compatibility analysis",
                "agents": ["CV Parser", "Job Analyzer", "Match Scorer", "Recommendation Writer"]
            },
            {
                "name": "meta_quest",
                "title": "Knowledge Q&A",
                "description": "Answer questions from your document knowledge base using RAG",
                "agents": ["Knowledge Retriever", "Context Analyzer", "Answer Synthesizer", "Answer Reviewer"]
            }
        ]
    }
