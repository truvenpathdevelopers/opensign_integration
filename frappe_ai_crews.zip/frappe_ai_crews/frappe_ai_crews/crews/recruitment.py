"""
Recruitment Crew - AI-powered candidate sourcing and evaluation
Based on: https://github.com/crewAIInc/crewAI-examples/tree/main/crews/recruitment
"""

import frappe
from frappe import _
from typing import Dict, Any, List
from frappe_ai_crews.crews.base import BaseCrew, CREWAI_AVAILABLE

if CREWAI_AVAILABLE:
    from crewai import Crew, Process


class RecruitmentCrew(BaseCrew):
    """
    Crew for recruitment and candidate sourcing.
    
    Agents:
    - Talent Sourcer: Finds potential candidates
    - Candidate Screener: Screens against requirements
    - Candidate Evaluator: In-depth evaluation
    - Recruitment Strategist: Creates outreach strategies
    """
    
    crew_name = "recruitment"
    
    def _get_tools(self, agent_name: str):
        """Get tools for recruitment agents."""
        tools = []
        try:
            from crewai_tools import SerperDevTool, WebsiteSearchTool
            if agent_name in ["talent_sourcer", "candidate_screener"]:
                tools.append(SerperDevTool())
                tools.append(WebsiteSearchTool())
        except ImportError:
            pass
        return tools
    
    def _build_crew(self) -> 'Crew':
        """Build the recruitment crew."""
        # Create agents
        talent_sourcer = self._create_agent("talent_sourcer")
        candidate_screener = self._create_agent("candidate_screener")
        candidate_evaluator = self._create_agent("candidate_evaluator")
        recruitment_strategist = self._create_agent("recruitment_strategist")
        
        # Create tasks with dependencies
        source_task = self._create_task("source_candidates", talent_sourcer)
        screen_task = self._create_task("screen_candidates", candidate_screener, [source_task])
        evaluate_task = self._create_task("evaluate_candidates", candidate_evaluator, [screen_task])
        strategy_task = self._create_task("create_outreach_strategy", recruitment_strategist, [evaluate_task])
        
        # Build crew
        return Crew(
            agents=[talent_sourcer, candidate_screener, candidate_evaluator, recruitment_strategist],
            tasks=[source_task, screen_task, evaluate_task, strategy_task],
            process=Process.sequential,
            verbose=self.verbose
        )


# =============================================================================
# FRAPPE API METHODS
# =============================================================================

@frappe.whitelist()
def run_recruitment(
    company_name: str,
    job_title: str,
    industry: str,
    requirements: str,
    must_have_skills: str = "",
    nice_to_have_skills: str = "",
    experience_level: str = "Mid-level",
    education: str = "",
    location: str = "",
    company_culture: str = "",
    value_proposition: str = "",
    salary_range: str = "",
    benefits: str = ""
) -> Dict[str, Any]:
    """
    Run recruitment crew to source and evaluate candidates.
    
    Args:
        company_name: Hiring company name
        job_title: Position title
        industry: Industry sector
        requirements: Job requirements
        must_have_skills: Required skills
        nice_to_have_skills: Preferred skills
        experience_level: Entry/Mid/Senior
        education: Education requirements
        location: Job location
        company_culture: Culture description
        value_proposition: Why join this company
        salary_range: Compensation range
        benefits: Benefits highlights
    
    Returns:
        Dictionary with recruitment results
    """
    inputs = {
        "company_name": company_name,
        "job_title": job_title,
        "industry": industry,
        "requirements": requirements,
        "must_have_skills": must_have_skills or "Not specified",
        "nice_to_have_skills": nice_to_have_skills or "Not specified",
        "experience_level": experience_level or "Mid-level",
        "education": education or "Bachelor's degree preferred",
        "location": location or "Remote",
        "company_culture": company_culture or "Collaborative and innovative",
        "value_proposition": value_proposition or "Great opportunity for growth",
        "salary_range": salary_range or "Competitive",
        "benefits": benefits or "Standard benefits package"
    }
    
    try:
        crew = RecruitmentCrew(inputs)
        result = crew.run()
        
        return {
            "success": True,
            "recruitment_report": result,
            "inputs": inputs
        }
    except Exception as e:
        frappe.log_error(f"Recruitment Error: {str(e)}", "AI Crews")
        return {
            "success": False,
            "error": str(e)
        }


@frappe.whitelist()
def run_recruitment_async(request_name: str) -> Dict[str, str]:
    """Queue recruitment as background job."""
    from frappe.utils.background_jobs import enqueue
    
    doc = frappe.get_doc("Recruitment Request", request_name)
    doc.status = "Processing"
    doc.save(ignore_permissions=True)
    frappe.db.commit()
    
    enqueue(
        "frappe_ai_crews.crews.recruitment.process_recruitment_request",
        request_name=request_name,
        queue="long",
        timeout=900
    )
    
    return {
        "success": True,
        "message": _("Recruitment process has been queued.")
    }


def process_recruitment_request(request_name: str):
    """Background job handler for recruitment."""
    try:
        doc = frappe.get_doc("Recruitment Request", request_name)
        
        inputs = {
            "company_name": doc.company_name,
            "job_title": doc.job_title,
            "industry": doc.industry,
            "requirements": doc.requirements or "",
            "must_have_skills": doc.must_have_skills or "Not specified",
            "nice_to_have_skills": doc.nice_to_have_skills or "Not specified",
            "experience_level": doc.experience_level or "Mid-level",
            "education": doc.education or "Bachelor's degree preferred",
            "location": doc.location or "Remote",
            "company_culture": doc.company_culture or "Collaborative",
            "value_proposition": doc.value_proposition or "Great opportunity",
            "salary_range": doc.salary_range or "Competitive",
            "benefits": doc.benefits or "Standard benefits"
        }
        
        crew = RecruitmentCrew(inputs)
        result = crew.run()
        
        doc.status = "Completed"
        doc.recruitment_report = result
        doc.save(ignore_permissions=True)
        frappe.db.commit()
        
        frappe.publish_realtime(
            "recruitment_complete",
            {"request_name": request_name, "success": True},
            user=doc.owner
        )
        
    except Exception as e:
        frappe.log_error(f"Recruitment Error: {str(e)}", "AI Crews")
        
        doc = frappe.get_doc("Recruitment Request", request_name)
        doc.status = "Error"
        doc.error_message = str(e)
        doc.save(ignore_permissions=True)
        frappe.db.commit()


def on_request_insert(doc, method):
    """Hook called when Recruitment Request is created."""
    if doc.auto_process:
        run_recruitment_async(doc.name)
