"""
Match Profile to Positions Crew - CV-to-Job matching with analysis
Based on: https://github.com/crewAIInc/crewAI-examples/tree/main/crews/match_profile_to_positions
"""

import frappe
from frappe import _
from typing import Dict, Any
from frappe_ai_crews.crews.base import BaseCrew, CREWAI_AVAILABLE

if CREWAI_AVAILABLE:
    from crewai import Crew, Process


class MatchProfileCrew(BaseCrew):
    """
    Crew for matching candidate profiles to job positions.
    
    Agents:
    - CV Parser: Extracts structured data from resumes
    - Job Analyzer: Analyzes job requirements
    - Match Scorer: Scores and analyzes compatibility
    - Recommendation Writer: Generates actionable recommendations
    """
    
    crew_name = "match_profile"
    
    def _get_tools(self, agent_name: str):
        """Get tools for match profile agents."""
        tools = []
        try:
            from crewai_tools import PDFSearchTool
            if agent_name == "cv_parser":
                # PDF tool for parsing CV documents
                pass
        except ImportError:
            pass
        return tools
    
    def _build_crew(self) -> 'Crew':
        """Build the match profile crew."""
        # Create agents
        cv_parser = self._create_agent("cv_parser")
        job_analyzer = self._create_agent("job_analyzer")
        match_scorer = self._create_agent("match_scorer")
        recommendation_writer = self._create_agent("recommendation_writer")
        
        # Create tasks with dependencies
        parse_task = self._create_task("parse_cv", cv_parser)
        analyze_task = self._create_task("analyze_job", job_analyzer)
        score_task = self._create_task("score_match", match_scorer, [parse_task, analyze_task])
        recommend_task = self._create_task("generate_recommendations", recommendation_writer, [score_task])
        
        # Build crew
        return Crew(
            agents=[cv_parser, job_analyzer, match_scorer, recommendation_writer],
            tasks=[parse_task, analyze_task, score_task, recommend_task],
            process=Process.sequential,
            verbose=self.verbose
        )


# =============================================================================
# FRAPPE API METHODS
# =============================================================================

@frappe.whitelist()
def match_profile_to_job(
    cv_content: str,
    job_title: str,
    company_name: str,
    job_description: str
) -> Dict[str, Any]:
    """
    Match a candidate profile to a job position.
    
    Args:
        cv_content: Full text content of the CV/resume
        job_title: Title of the position
        company_name: Hiring company name
        job_description: Full job description
    
    Returns:
        Dictionary with match analysis and recommendations
    """
    inputs = {
        "cv_content": cv_content,
        "job_title": job_title,
        "company_name": company_name,
        "job_description": job_description
    }
    
    try:
        crew = MatchProfileCrew(inputs)
        result = crew.run()
        
        return {
            "success": True,
            "match_report": result,
            "inputs": {
                "job_title": job_title,
                "company_name": company_name
            }
        }
    except Exception as e:
        frappe.log_error(f"Profile Match Error: {str(e)}", "AI Crews")
        return {
            "success": False,
            "error": str(e)
        }


@frappe.whitelist()
def match_profile_async(request_name: str) -> Dict[str, str]:
    """Queue profile matching as background job."""
    from frappe.utils.background_jobs import enqueue
    
    doc = frappe.get_doc("Profile Match Request", request_name)
    doc.status = "Processing"
    doc.save(ignore_permissions=True)
    frappe.db.commit()
    
    enqueue(
        "frappe_ai_crews.crews.match_profile.process_match_request",
        request_name=request_name,
        queue="long",
        timeout=600
    )
    
    return {
        "success": True,
        "message": _("Profile matching has been queued.")
    }


def process_match_request(request_name: str):
    """Background job handler for profile matching."""
    try:
        doc = frappe.get_doc("Profile Match Request", request_name)
        
        # Get CV content from attached file or text field
        cv_content = doc.cv_content
        if not cv_content and doc.cv_file:
            cv_content = extract_cv_content(doc.cv_file)
        
        inputs = {
            "cv_content": cv_content,
            "job_title": doc.job_title,
            "company_name": doc.company_name,
            "job_description": doc.job_description
        }
        
        crew = MatchProfileCrew(inputs)
        result = crew.run()
        
        # Parse match score if present in result
        match_score = extract_match_score(result)
        
        doc.status = "Completed"
        doc.match_report = result
        doc.match_score = match_score
        doc.save(ignore_permissions=True)
        frappe.db.commit()
        
        frappe.publish_realtime(
            "profile_match_complete",
            {"request_name": request_name, "success": True, "score": match_score},
            user=doc.owner
        )
        
    except Exception as e:
        frappe.log_error(f"Profile Match Error: {str(e)}", "AI Crews")
        
        doc = frappe.get_doc("Profile Match Request", request_name)
        doc.status = "Error"
        doc.error_message = str(e)
        doc.save(ignore_permissions=True)
        frappe.db.commit()


def extract_cv_content(file_url: str) -> str:
    """Extract text content from a CV file."""
    import os
    
    file_path = frappe.get_site_path("public", file_url.lstrip("/"))
    
    if not os.path.exists(file_path):
        file_path = frappe.get_site_path("private", "files", os.path.basename(file_url))
    
    if not os.path.exists(file_path):
        return ""
    
    # Handle PDF files
    if file_path.lower().endswith(".pdf"):
        try:
            from pypdf import PdfReader
            reader = PdfReader(file_path)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            return text
        except Exception as e:
            frappe.log_error(f"PDF extraction error: {e}", "AI Crews")
            return ""
    
    # Handle text files
    elif file_path.lower().endswith((".txt", ".md")):
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    
    # Handle Word documents
    elif file_path.lower().endswith(".docx"):
        try:
            from docx import Document
            doc = Document(file_path)
            return "\n".join([para.text for para in doc.paragraphs])
        except Exception as e:
            frappe.log_error(f"DOCX extraction error: {e}", "AI Crews")
            return ""
    
    return ""


def extract_match_score(result: str) -> float:
    """Extract match score from result text."""
    import re
    
    # Look for patterns like "Match Score: 85" or "Overall: 75%"
    patterns = [
        r"match\s*score[:\s]+(\d+(?:\.\d+)?)",
        r"overall[:\s]+(\d+(?:\.\d+)?)",
        r"compatibility[:\s]+(\d+(?:\.\d+)?)",
        r"(\d+(?:\.\d+)?)\s*(?:%|percent|out of 100)"
    ]
    
    for pattern in patterns:
        match = re.search(pattern, result.lower())
        if match:
            try:
                score = float(match.group(1))
                if score > 100:
                    score = score / 10  # Normalize if > 100
                return min(score, 100)
            except:
                pass
    
    return 0.0


def on_request_insert(doc, method):
    """Hook called when Profile Match Request is created."""
    if doc.auto_process:
        match_profile_async(doc.name)


@frappe.whitelist()
def batch_match_profiles(
    cv_contents: list,
    job_title: str,
    company_name: str,
    job_description: str
) -> Dict[str, Any]:
    """
    Match multiple candidate profiles to a job position.
    
    Args:
        cv_contents: List of CV text contents
        job_title: Title of the position
        company_name: Hiring company name
        job_description: Full job description
    
    Returns:
        Dictionary with batch match results
    """
    import json
    if isinstance(cv_contents, str):
        cv_contents = json.loads(cv_contents)
    
    results = []
    for i, cv in enumerate(cv_contents):
        try:
            result = match_profile_to_job(cv, job_title, company_name, job_description)
            result["candidate_index"] = i
            results.append(result)
        except Exception as e:
            results.append({
                "success": False,
                "candidate_index": i,
                "error": str(e)
            })
    
    # Sort by match score
    successful = [r for r in results if r.get("success")]
    successful.sort(key=lambda x: extract_match_score(x.get("match_report", "")), reverse=True)
    
    return {
        "success": True,
        "total_candidates": len(cv_contents),
        "successful_matches": len(successful),
        "results": results,
        "ranked_results": successful
    }
