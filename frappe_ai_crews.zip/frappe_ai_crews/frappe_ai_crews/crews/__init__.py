"""
Frappe AI Crews - Crew Implementations
=======================================

This module contains all CrewAI crew implementations.
"""

from frappe_ai_crews.crews.base import BaseCrew
from frappe_ai_crews.crews.job_posting import JobPostingCrew
from frappe_ai_crews.crews.recruitment import RecruitmentCrew
from frappe_ai_crews.crews.match_profile import MatchProfileCrew
from frappe_ai_crews.crews.meta_quest import MetaQuestCrew

__all__ = [
    'BaseCrew',
    'JobPostingCrew',
    'RecruitmentCrew',
    'MatchProfileCrew',
    'MetaQuestCrew'
]
