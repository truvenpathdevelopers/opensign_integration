"""
Meta Quest Knowledge Crew - PDF-based Q&A system using RAG
Based on: https://github.com/crewAIInc/crewAI-examples/tree/main/crews/meta_quest_knowledge
"""

import os
import frappe
from frappe import _
from typing import Dict, Any, List, Optional
from frappe_ai_crews.crews.base import BaseCrew, CREWAI_AVAILABLE

if CREWAI_AVAILABLE:
    from crewai import Crew, Process

# RAG imports
try:
    from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain_community.vectorstores import Chroma
    from langchain_community.embeddings import OpenAIEmbeddings
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False


class KnowledgeBase:
    """
    Manages a vector knowledge base for document Q&A.
    """
    
    def __init__(self, name: str, persist_directory: str = None):
        self.name = name
        self.persist_directory = persist_directory or os.path.join(
            frappe.get_site_path(), "private", "knowledge_bases", name
        )
        self.vectorstore = None
        self.embeddings = None
    
    def initialize(self):
        """Initialize embeddings and load existing vectorstore if present."""
        if not RAG_AVAILABLE:
            frappe.throw(_("RAG dependencies not installed. Please install langchain and chromadb."))
        
        self.embeddings = OpenAIEmbeddings()
        
        if os.path.exists(self.persist_directory):
            self.vectorstore = Chroma(
                persist_directory=self.persist_directory,
                embedding_function=self.embeddings
            )
    
    def add_documents(self, file_paths: List[str]):
        """Add documents to the knowledge base."""
        if not RAG_AVAILABLE:
            frappe.throw(_("RAG dependencies not installed."))
        
        all_docs = []
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        
        for file_path in file_paths:
            if file_path.lower().endswith(".pdf"):
                loader = PyPDFLoader(file_path)
                docs = loader.load()
                splits = text_splitter.split_documents(docs)
                all_docs.extend(splits)
        
        if all_docs:
            if self.vectorstore is None:
                self.vectorstore = Chroma.from_documents(
                    documents=all_docs,
                    embedding=self.embeddings,
                    persist_directory=self.persist_directory
                )
            else:
                self.vectorstore.add_documents(all_docs)
            
            self.vectorstore.persist()
    
    def search(self, query: str, k: int = 5) -> List[Dict]:
        """Search the knowledge base."""
        if self.vectorstore is None:
            return []
        
        results = self.vectorstore.similarity_search_with_score(query, k=k)
        
        return [
            {
                "content": doc.page_content,
                "metadata": doc.metadata,
                "score": float(score)
            }
            for doc, score in results
        ]


class MetaQuestCrew(BaseCrew):
    """
    Crew for answering questions from a knowledge base.
    
    Agents:
    - Knowledge Retriever: Searches the knowledge base
    - Context Analyzer: Analyzes retrieved documents
    - Answer Synthesizer: Creates comprehensive answers
    - Answer Reviewer: Reviews for accuracy and quality
    """
    
    crew_name = "meta_quest"
    
    def __init__(self, inputs: Dict[str, Any], knowledge_base: KnowledgeBase = None):
        super().__init__(inputs)
        self.knowledge_base = knowledge_base
        
        # Pre-fetch relevant documents if knowledge base is available
        if self.knowledge_base and inputs.get("question"):
            search_results = self.knowledge_base.search(inputs["question"], k=5)
            self.inputs["retrieved_documents"] = "\n\n".join([
                f"[Source: {r['metadata'].get('source', 'Unknown')}]\n{r['content']}"
                for r in search_results
            ])
    
    def _build_crew(self) -> 'Crew':
        """Build the knowledge Q&A crew."""
        # Create agents
        knowledge_retriever = self._create_agent("knowledge_retriever")
        context_analyzer = self._create_agent("context_analyzer")
        answer_synthesizer = self._create_agent("answer_synthesizer")
        answer_reviewer = self._create_agent("answer_reviewer")
        
        # Create tasks with dependencies
        retrieve_task = self._create_task("retrieve_knowledge", knowledge_retriever)
        analyze_task = self._create_task("analyze_context", context_analyzer, [retrieve_task])
        synthesize_task = self._create_task("synthesize_answer", answer_synthesizer, [analyze_task])
        review_task = self._create_task("review_answer", answer_reviewer, [synthesize_task])
        
        # Build crew
        return Crew(
            agents=[knowledge_retriever, context_analyzer, answer_synthesizer, answer_reviewer],
            tasks=[retrieve_task, analyze_task, synthesize_task, review_task],
            process=Process.sequential,
            verbose=self.verbose
        )


# =============================================================================
# KNOWLEDGE BASE MANAGEMENT
# =============================================================================

@frappe.whitelist()
def create_knowledge_base(name: str, description: str = "") -> Dict[str, Any]:
    """Create a new knowledge base."""
    try:
        kb = KnowledgeBase(name)
        kb.initialize()
        
        # Create a record in the database
        if not frappe.db.exists("Knowledge Base", name):
            doc = frappe.get_doc({
                "doctype": "Knowledge Base",
                "name": name,
                "description": description,
                "status": "Active"
            })
            doc.insert(ignore_permissions=True)
            frappe.db.commit()
        
        return {
            "success": True,
            "name": name,
            "message": _("Knowledge base created successfully.")
        }
    except Exception as e:
        frappe.log_error(f"Knowledge Base Creation Error: {str(e)}", "AI Crews")
        return {
            "success": False,
            "error": str(e)
        }


@frappe.whitelist()
def add_documents_to_kb(kb_name: str, file_urls: list) -> Dict[str, Any]:
    """Add documents to a knowledge base."""
    import json
    if isinstance(file_urls, str):
        file_urls = json.loads(file_urls)
    
    try:
        kb = KnowledgeBase(kb_name)
        kb.initialize()
        
        # Convert URLs to file paths
        file_paths = []
        for url in file_urls:
            path = frappe.get_site_path("public", url.lstrip("/"))
            if not os.path.exists(path):
                path = frappe.get_site_path("private", "files", os.path.basename(url))
            if os.path.exists(path):
                file_paths.append(path)
        
        kb.add_documents(file_paths)
        
        return {
            "success": True,
            "documents_added": len(file_paths),
            "message": _("Documents added to knowledge base.")
        }
    except Exception as e:
        frappe.log_error(f"Add Documents Error: {str(e)}", "AI Crews")
        return {
            "success": False,
            "error": str(e)
        }


# =============================================================================
# FRAPPE API METHODS
# =============================================================================

@frappe.whitelist()
def query_knowledge_base(
    question: str,
    knowledge_base_name: str
) -> Dict[str, Any]:
    """
    Query a knowledge base with a question.
    
    Args:
        question: The question to answer
        knowledge_base_name: Name of the knowledge base to query
    
    Returns:
        Dictionary with the answer and supporting information
    """
    try:
        # Initialize knowledge base
        kb = KnowledgeBase(knowledge_base_name)
        kb.initialize()
        
        # Search for relevant documents
        search_results = kb.search(question, k=5)
        
        if not search_results:
            return {
                "success": True,
                "answer": _("No relevant information found in the knowledge base."),
                "sources": []
            }
        
        inputs = {
            "question": question,
            "knowledge_base_name": knowledge_base_name,
            "retrieved_documents": "\n\n".join([
                f"[Source: {r['metadata'].get('source', 'Unknown')}]\n{r['content']}"
                for r in search_results
            ])
        }
        
        crew = MetaQuestCrew(inputs, knowledge_base=kb)
        result = crew.run()
        
        return {
            "success": True,
            "answer": result,
            "sources": [
                {
                    "source": r["metadata"].get("source", "Unknown"),
                    "page": r["metadata"].get("page", "N/A"),
                    "relevance": r["score"]
                }
                for r in search_results
            ]
        }
    except Exception as e:
        frappe.log_error(f"Knowledge Query Error: {str(e)}", "AI Crews")
        return {
            "success": False,
            "error": str(e)
        }


@frappe.whitelist()
def query_knowledge_async(query_name: str) -> Dict[str, str]:
    """Queue knowledge query as background job."""
    from frappe.utils.background_jobs import enqueue
    
    doc = frappe.get_doc("Knowledge Query", query_name)
    doc.status = "Processing"
    doc.save(ignore_permissions=True)
    frappe.db.commit()
    
    enqueue(
        "frappe_ai_crews.crews.meta_quest.process_knowledge_query",
        query_name=query_name,
        queue="long",
        timeout=300
    )
    
    return {
        "success": True,
        "message": _("Query is being processed.")
    }


def process_knowledge_query(query_name: str):
    """Background job handler for knowledge queries."""
    try:
        doc = frappe.get_doc("Knowledge Query", query_name)
        
        result = query_knowledge_base(
            question=doc.question,
            knowledge_base_name=doc.knowledge_base
        )
        
        if result.get("success"):
            doc.status = "Completed"
            doc.answer = result.get("answer", "")
            doc.sources = str(result.get("sources", []))
        else:
            doc.status = "Error"
            doc.error_message = result.get("error", "Unknown error")
        
        doc.save(ignore_permissions=True)
        frappe.db.commit()
        
        frappe.publish_realtime(
            "knowledge_query_complete",
            {"query_name": query_name, "success": result.get("success")},
            user=doc.owner
        )
        
    except Exception as e:
        frappe.log_error(f"Knowledge Query Error: {str(e)}", "AI Crews")
        
        doc = frappe.get_doc("Knowledge Query", query_name)
        doc.status = "Error"
        doc.error_message = str(e)
        doc.save(ignore_permissions=True)
        frappe.db.commit()


def on_query_insert(doc, method):
    """Hook called when Knowledge Query is created."""
    if doc.auto_process:
        query_knowledge_async(doc.name)


@frappe.whitelist()
def simple_search(question: str, knowledge_base_name: str, k: int = 5) -> Dict[str, Any]:
    """
    Simple semantic search without full crew processing.
    Faster but less comprehensive than full query.
    """
    try:
        kb = KnowledgeBase(knowledge_base_name)
        kb.initialize()
        
        results = kb.search(question, k=k)
        
        return {
            "success": True,
            "results": results
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
