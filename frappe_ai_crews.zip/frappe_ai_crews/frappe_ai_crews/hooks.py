app_name = "frappe_ai_crews"
app_title = "Frappe AI Crews"
app_publisher = "Your Company"
app_description = "CrewAI Multi-Agent AI System for HR & Knowledge Management"
app_email = "info@yourcompany.com"
app_license = "MIT"
app_icon = "octicon octicon-hubot"
app_color = "purple"
app_version = "1.0.0"

required_apps = ["frappe"]

# Installation hooks
after_install = "frappe_ai_crews.install.after_install"
before_uninstall = "frappe_ai_crews.install.before_uninstall"

# Includes in <head>
app_include_css = "/assets/frappe_ai_crews/css/ai_crews.css"
app_include_js = "/assets/frappe_ai_crews/js/ai_crews.js"

# Document Events
doc_events = {
    "Job Posting Request": {
        "after_insert": "frappe_ai_crews.crews.job_posting.on_request_insert"
    },
    "Recruitment Request": {
        "after_insert": "frappe_ai_crews.crews.recruitment.on_request_insert"
    },
    "Profile Match Request": {
        "after_insert": "frappe_ai_crews.crews.match_profile.on_request_insert"
    },
    "Knowledge Query": {
        "after_insert": "frappe_ai_crews.crews.meta_quest.on_query_insert"
    }
}

# Scheduled Tasks
scheduler_events = {
    "hourly": [
        "frappe_ai_crews.crews.utils.process_pending_requests"
    ]
}

# Fixtures
fixtures = []

# Jinja
jinja = {
    "methods": []
}
