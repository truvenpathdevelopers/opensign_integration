frappe.ui.form.on('Profile Match Request', {
    refresh: function(frm) {
        if (frm.doc.status !== 'Completed' && frm.doc.status !== 'Processing') {
            frm.add_custom_button(__('Analyze Match'), function() {
                frappe.confirm(
                    __('This will analyze the CV against the job requirements. Continue?'),
                    function() {
                        frm.call('run_match').then(() => {
                            frm.reload_doc();
                        });
                    }
                );
            }, __('Actions'));
        }
        
        // Show match score prominently if completed
        if (frm.doc.status === 'Completed' && frm.doc.match_score) {
            let color = frm.doc.match_score >= 70 ? 'green' : 
                       frm.doc.match_score >= 50 ? 'orange' : 'red';
            frm.dashboard.add_indicator(
                __('Match Score: {0}%', [frm.doc.match_score.toFixed(0)]), 
                color
            );
        }
        
        if (frm.doc.status === 'Processing') {
            frm.dashboard.set_headline_alert(
                '<span class="indicator orange">Analyzing... Please wait.</span>'
            );
        }
    },
    
    onload: function(frm) {
        frappe.realtime.on('profile_match_complete', function(data) {
            if (data.request_name === frm.doc.name) {
                frm.reload_doc();
                if (data.success) {
                    frappe.show_alert({
                        message: __('Match analysis complete! Score: {0}%', [data.score]),
                        indicator: 'green'
                    });
                }
            }
        });
    }
});
