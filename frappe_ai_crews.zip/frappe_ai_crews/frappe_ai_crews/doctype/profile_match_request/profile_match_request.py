"""Profile Match Request DocType Controller"""

import frappe
from frappe.model.document import Document


class ProfileMatchRequest(Document):
    def before_save(self):
        if self.is_new() and not self.status:
            self.status = "Draft"

    @frappe.whitelist()
    def run_match(self):
        """Trigger profile matching."""
        from frappe_ai_crews.crews.match_profile import match_profile_async
        
        self.status = "Pending"
        self.save()
        
        match_profile_async(self.name)
        
        frappe.msgprint(
            "Profile matching has been queued. You will be notified when complete.",
            indicator="blue",
            title="Processing"
        )
