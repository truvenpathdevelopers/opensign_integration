"""Knowledge Base Document Child Table Controller"""

import frappe
from frappe.model.document import Document


class KnowledgeBaseDocument(Document):
    pass
