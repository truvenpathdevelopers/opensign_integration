"""AI Crew Settings DocType Controller"""

import frappe
from frappe.model.document import Document


class AICrewSettings(Document):
    def validate(self):
        if self.openai_api_key and not self.openai_api_key.startswith("sk-"):
            frappe.msgprint(
                "OpenAI API key should start with 'sk-'. Please verify your key.",
                indicator="orange",
                title="API Key Warning"
            )
    
    def on_update(self):
        frappe.cache().delete_key("ai_crew_settings")
