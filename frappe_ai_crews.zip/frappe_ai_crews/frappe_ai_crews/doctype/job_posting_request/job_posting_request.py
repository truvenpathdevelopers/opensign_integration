"""Job Posting Request DocType Controller"""

import frappe
from frappe.model.document import Document


class JobPostingRequest(Document):
    def before_save(self):
        if self.is_new() and not self.status:
            self.status = "Draft"
    
    def on_submit(self):
        if self.status == "Draft":
            self.status = "Pending"
            self.save()

    @frappe.whitelist()
    def generate_posting(self):
        """Trigger job posting generation."""
        from frappe_ai_crews.crews.job_posting import generate_job_posting_async
        
        self.status = "Pending"
        self.save()
        
        generate_job_posting_async(self.name)
        
        frappe.msgprint(
            "Job posting generation has been queued. You will be notified when complete.",
            indicator="blue",
            title="Processing"
        )

    @frappe.whitelist()
    def copy_to_clipboard(self):
        """Return the generated posting for copying."""
        if self.generated_posting:
            return self.generated_posting
        else:
            frappe.throw("No generated posting available.")
