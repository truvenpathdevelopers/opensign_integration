frappe.ui.form.on('Job Posting Request', {
    refresh: function(frm) {
        // Add Generate button if not completed
        if (frm.doc.status !== 'Completed' && frm.doc.status !== 'Processing') {
            frm.add_custom_button(__('Generate Job Posting'), function() {
                frappe.confirm(
                    __('This will use AI to generate a job posting. Continue?'),
                    function() {
                        frm.call('generate_posting').then(() => {
                            frm.reload_doc();
                        });
                    }
                );
            }, __('Actions'));
        }
        
        // Add Copy button if completed
        if (frm.doc.status === 'Completed' && frm.doc.generated_posting) {
            frm.add_custom_button(__('Copy to Clipboard'), function() {
                // Strip HTML tags for plain text
                let text = frm.doc.generated_posting.replace(/<[^>]*>/g, '');
                navigator.clipboard.writeText(text).then(() => {
                    frappe.show_alert({
                        message: __('Copied to clipboard!'),
                        indicator: 'green'
                    });
                });
            }, __('Actions'));
            
            frm.add_custom_button(__('Download as Text'), function() {
                let text = frm.doc.generated_posting.replace(/<[^>]*>/g, '');
                let blob = new Blob([text], {type: 'text/plain'});
                let url = URL.createObjectURL(blob);
                let a = document.createElement('a');
                a.href = url;
                a.download = `${frm.doc.job_title}_job_posting.txt`;
                a.click();
            }, __('Actions'));
        }
        
        // Status indicator
        if (frm.doc.status === 'Processing') {
            frm.dashboard.set_headline_alert(
                '<span class="indicator orange">Processing... Please wait.</span>'
            );
        }
    },
    
    onload: function(frm) {
        // Listen for real-time updates
        frappe.realtime.on('job_posting_complete', function(data) {
            if (data.request_name === frm.doc.name) {
                frm.reload_doc();
                if (data.success) {
                    frappe.show_alert({
                        message: __('Job posting generated successfully!'),
                        indicator: 'green'
                    });
                } else {
                    frappe.show_alert({
                        message: __('Error generating job posting: ') + data.error,
                        indicator: 'red'
                    });
                }
            }
        });
    }
});
