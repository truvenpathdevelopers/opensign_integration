"""Knowledge Query DocType Controller"""

import frappe
from frappe.model.document import Document


class KnowledgeQuery(Document):
    def before_save(self):
        if self.is_new() and not self.status:
            self.status = "Draft"

    @frappe.whitelist()
    def run_query(self):
        """Run the knowledge query."""
        from frappe_ai_crews.crews.meta_quest import query_knowledge_async
        
        self.status = "Pending"
        self.save()
        
        query_knowledge_async(self.name)
        
        frappe.msgprint(
            "Query is being processed. You will be notified when complete.",
            indicator="blue",
            title="Processing"
        )
