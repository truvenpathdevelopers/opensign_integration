frappe.ui.form.on('Knowledge Query', {
    refresh: function(frm) {
        if (frm.doc.status !== 'Completed' && frm.doc.status !== 'Processing') {
            frm.add_custom_button(__('Ask Question'), function() {
                frm.call('run_query').then(() => {
                    frm.reload_doc();
                });
            }, __('Actions'));
        }
        
        if (frm.doc.status === 'Processing') {
            frm.dashboard.set_headline_alert(
                '<span class="indicator orange">Searching knowledge base...</span>'
            );
        }
    },
    
    onload: function(frm) {
        frappe.realtime.on('knowledge_query_complete', function(data) {
            if (data.query_name === frm.doc.name) {
                frm.reload_doc();
                frappe.show_alert({
                    message: data.success ? __('Answer found!') : __('Error processing query'),
                    indicator: data.success ? 'green' : 'red'
                });
            }
        });
    }
});
