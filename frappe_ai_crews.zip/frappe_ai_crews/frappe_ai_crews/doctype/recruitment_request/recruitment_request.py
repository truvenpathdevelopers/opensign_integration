"""Recruitment Request DocType Controller"""

import frappe
from frappe.model.document import Document


class RecruitmentRequest(Document):
    def before_save(self):
        if self.is_new() and not self.status:
            self.status = "Draft"

    @frappe.whitelist()
    def run_recruitment(self):
        """Trigger recruitment process."""
        from frappe_ai_crews.crews.recruitment import run_recruitment_async
        
        self.status = "Pending"
        self.save()
        
        run_recruitment_async(self.name)
        
        frappe.msgprint(
            "Recruitment process has been queued. You will be notified when complete.",
            indicator="blue",
            title="Processing"
        )
