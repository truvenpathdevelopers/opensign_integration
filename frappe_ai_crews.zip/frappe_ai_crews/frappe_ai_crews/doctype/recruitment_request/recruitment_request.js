frappe.ui.form.on('Recruitment Request', {
    refresh: function(frm) {
        if (frm.doc.status !== 'Completed' && frm.doc.status !== 'Processing') {
            frm.add_custom_button(__('Run Recruitment'), function() {
                frappe.confirm(
                    __('This will use AI to source and evaluate candidates. Continue?'),
                    function() {
                        frm.call('run_recruitment').then(() => {
                            frm.reload_doc();
                        });
                    }
                );
            }, __('Actions'));
        }
        
        if (frm.doc.status === 'Processing') {
            frm.dashboard.set_headline_alert(
                '<span class="indicator orange">Processing... This may take several minutes.</span>'
            );
        }
    },
    
    onload: function(frm) {
        frappe.realtime.on('recruitment_complete', function(data) {
            if (data.request_name === frm.doc.name) {
                frm.reload_doc();
                frappe.show_alert({
                    message: data.success ? __('Recruitment completed!') : __('Error: ') + data.error,
                    indicator: data.success ? 'green' : 'red'
                });
            }
        });
    }
});
