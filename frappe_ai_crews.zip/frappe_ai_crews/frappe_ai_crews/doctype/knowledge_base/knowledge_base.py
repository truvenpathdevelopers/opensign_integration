"""Knowledge Base DocType Controller"""

import frappe
from frappe.model.document import Document


class KnowledgeBase(Document):
    def validate(self):
        self.document_count = len(self.documents) if self.documents else 0
    
    @frappe.whitelist()
    def rebuild_index(self):
        """Rebuild the vector index for this knowledge base."""
        from frappe_ai_crews.crews.meta_quest import KnowledgeBase as KB
        
        self.status = "Processing"
        self.save()
        
        try:
            kb = KB(self.kb_name)
            kb.initialize()
            
            # Get file paths from documents
            file_paths = []
            for doc in self.documents:
                if doc.file:
                    path = frappe.get_site_path("public", doc.file.lstrip("/"))
                    import os
                    if not os.path.exists(path):
                        path = frappe.get_site_path("private", "files", os.path.basename(doc.file))
                    if os.path.exists(path):
                        file_paths.append(path)
            
            if file_paths:
                kb.add_documents(file_paths)
            
            self.status = "Active"
            self.save()
            
            frappe.msgprint(
                f"Index rebuilt with {len(file_paths)} documents.",
                indicator="green",
                title="Success"
            )
        except Exception as e:
            self.status = "Active"
            self.save()
            frappe.throw(str(e))
    
    @frappe.whitelist()
    def test_query(self, question):
        """Test a query against this knowledge base."""
        from frappe_ai_crews.crews.meta_quest import simple_search
        
        result = simple_search(question, self.kb_name, k=3)
        return result
