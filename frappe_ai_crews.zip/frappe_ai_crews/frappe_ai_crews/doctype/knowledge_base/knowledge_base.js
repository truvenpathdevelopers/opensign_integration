frappe.ui.form.on('Knowledge Base', {
    refresh: function(frm) {
        frm.add_custom_button(__('Rebuild Index'), function() {
            frappe.confirm(
                __('This will rebuild the vector index for all documents. Continue?'),
                function() {
                    frm.call('rebuild_index').then(() => {
                        frm.reload_doc();
                    });
                }
            );
        }, __('Actions'));
        
        frm.add_custom_button(__('Test Query'), function() {
            frappe.prompt({
                fieldname: 'question',
                fieldtype: 'Small Text',
                label: 'Test Question',
                reqd: 1
            }, function(values) {
                frm.call('test_query', {question: values.question}).then(r => {
                    if (r.message && r.message.success) {
                        let results = r.message.results || [];
                        let html = '<h4>Search Results</h4>';
                        results.forEach((res, i) => {
                            html += `<div class="mb-3 p-2 border rounded">
                                <strong>Result ${i+1}</strong> (Score: ${res.score.toFixed(3)})<br>
                                <small class="text-muted">${res.content.substring(0, 200)}...</small>
                            </div>`;
                        });
                        frappe.msgprint({
                            title: __('Search Results'),
                            message: html,
                            wide: true
                        });
                    } else {
                        frappe.msgprint(__('No results found or error occurred.'));
                    }
                });
            }, __('Test Query'), __('Search'));
        }, __('Actions'));
    }
});
