"""
Frappe AI Crews - Multi-Agent AI System for HR & Knowledge Management
======================================================================

A comprehensive Frappe app integrating CrewAI multi-agent framework for:
- Job Posting Generation
- Recruitment & Candidate Sourcing  
- CV-to-Job Matching
- Knowledge Base Q&A (Meta Quest style)

Based on CrewAI examples: https://github.com/crewAIInc/crewAI-examples
"""

__version__ = '1.0.0'
__title__ = "Frappe AI Crews"
__author__ = "Your Company"
__license__ = "MIT"
