/**
 * Frappe AI Crews - Client-Side Library
 * =====================================
 * 
 * Provides UI components and helper functions for AI Crews operations.
 */

frappe.provide("ai_crews");

// =============================================================================
// CREW STATUS CHECK
// =============================================================================

ai_crews.check_status = function() {
    return frappe.call({
        method: "frappe_ai_crews.crews.utils.check_ai_status",
        async: false
    }).then(r => r.message);
};

ai_crews.show_status = function() {
    frappe.call({
        method: "frappe_ai_crews.crews.utils.check_ai_status",
        callback: function(r) {
            if (r.message) {
                let status = r.message;
                let html = `
                    <table class="table table-bordered">
                        <tr>
                            <td>CrewAI Installed</td>
                            <td>${status.crewai_installed ? '✅' : '❌'}</td>
                        </tr>
                        <tr>
                            <td>CrewAI Tools Installed</td>
                            <td>${status.tools_installed ? '✅' : '❌'}</td>
                        </tr>
                        <tr>
                            <td>RAG Available</td>
                            <td>${status.rag_available ? '✅' : '❌'}</td>
                        </tr>
                        <tr>
                            <td>OpenAI Configured</td>
                            <td>${status.openai_configured ? '✅' : '❌'}</td>
                        </tr>
                        <tr>
                            <td>Serper Configured</td>
                            <td>${status.serper_configured ? '✅' : '❌'}</td>
                        </tr>
                        <tr class="${status.ready ? 'table-success' : 'table-danger'}">
                            <td><strong>Ready to Use</strong></td>
                            <td><strong>${status.ready ? '✅ Yes' : '❌ No'}</strong></td>
                        </tr>
                    </table>
                `;
                
                frappe.msgprint({
                    title: __('AI Crews Status'),
                    message: html,
                    indicator: status.ready ? 'green' : 'red'
                });
            }
        }
    });
};

// =============================================================================
// JOB POSTING
// =============================================================================

ai_crews.create_job_posting = function(options = {}) {
    let d = new frappe.ui.Dialog({
        title: __('Create Job Posting'),
        size: 'large',
        fields: [
            {
                fieldname: 'company_name',
                fieldtype: 'Data',
                label: __('Company Name'),
                reqd: 1,
                default: options.company_name || ''
            },
            {
                fieldname: 'job_title',
                fieldtype: 'Data',
                label: __('Job Title'),
                reqd: 1,
                default: options.job_title || ''
            },
            {
                fieldname: 'industry',
                fieldtype: 'Data',
                label: __('Industry'),
                reqd: 1,
                default: options.industry || ''
            },
            {
                fieldtype: 'Column Break'
            },
            {
                fieldname: 'work_location',
                fieldtype: 'Select',
                label: __('Work Location'),
                options: 'Office\nRemote\nHybrid',
                default: 'Office'
            },
            {
                fieldname: 'employment_type',
                fieldtype: 'Select',
                label: __('Employment Type'),
                options: 'Full-time\nPart-time\nContract\nInternship',
                default: 'Full-time'
            },
            {
                fieldname: 'salary_range',
                fieldtype: 'Data',
                label: __('Salary Range')
            },
            {
                fieldtype: 'Section Break',
                label: __('Requirements')
            },
            {
                fieldname: 'requirements',
                fieldtype: 'Text Editor',
                label: __('Job Requirements')
            }
        ],
        primary_action_label: __('Generate'),
        primary_action: function(values) {
            d.hide();
            
            frappe.call({
                method: "frappe_ai_crews.crews.job_posting.generate_job_posting",
                args: values,
                freeze: true,
                freeze_message: __('Generating job posting with AI... This may take a few minutes.'),
                callback: function(r) {
                    if (r.message && r.message.success) {
                        frappe.msgprint({
                            title: __('Job Posting Generated'),
                            message: r.message.job_posting,
                            wide: true
                        });
                    } else {
                        frappe.msgprint({
                            title: __('Error'),
                            message: r.message.error || __('An error occurred'),
                            indicator: 'red'
                        });
                    }
                }
            });
        }
    });
    
    d.show();
};

// =============================================================================
// PROFILE MATCHING
// =============================================================================

ai_crews.match_profile = function(options = {}) {
    let d = new frappe.ui.Dialog({
        title: __('Match Profile to Job'),
        size: 'extra-large',
        fields: [
            {
                fieldname: 'job_title',
                fieldtype: 'Data',
                label: __('Job Title'),
                reqd: 1
            },
            {
                fieldname: 'company_name',
                fieldtype: 'Data',
                label: __('Company Name'),
                reqd: 1
            },
            {
                fieldtype: 'Section Break',
                label: __('CV/Resume')
            },
            {
                fieldname: 'cv_content',
                fieldtype: 'Text Editor',
                label: __('Paste CV Content'),
                reqd: 1
            },
            {
                fieldtype: 'Section Break',
                label: __('Job Description')
            },
            {
                fieldname: 'job_description',
                fieldtype: 'Text Editor',
                label: __('Job Description'),
                reqd: 1
            }
        ],
        primary_action_label: __('Analyze Match'),
        primary_action: function(values) {
            d.hide();
            
            frappe.call({
                method: "frappe_ai_crews.crews.match_profile.match_profile_to_job",
                args: values,
                freeze: true,
                freeze_message: __('Analyzing profile match... This may take a few minutes.'),
                callback: function(r) {
                    if (r.message && r.message.success) {
                        frappe.msgprint({
                            title: __('Match Analysis'),
                            message: r.message.match_report,
                            wide: true
                        });
                    } else {
                        frappe.msgprint({
                            title: __('Error'),
                            message: r.message.error || __('An error occurred'),
                            indicator: 'red'
                        });
                    }
                }
            });
        }
    });
    
    d.show();
};

// =============================================================================
// KNOWLEDGE BASE QUERY
// =============================================================================

ai_crews.ask_knowledge_base = function(knowledge_base_name) {
    let d = new frappe.ui.Dialog({
        title: __('Ask Knowledge Base'),
        fields: [
            {
                fieldname: 'knowledge_base',
                fieldtype: 'Link',
                label: __('Knowledge Base'),
                options: 'Knowledge Base',
                reqd: 1,
                default: knowledge_base_name
            },
            {
                fieldname: 'question',
                fieldtype: 'Small Text',
                label: __('Your Question'),
                reqd: 1
            }
        ],
        primary_action_label: __('Ask'),
        primary_action: function(values) {
            d.hide();
            
            frappe.call({
                method: "frappe_ai_crews.crews.meta_quest.query_knowledge_base",
                args: {
                    question: values.question,
                    knowledge_base_name: values.knowledge_base
                },
                freeze: true,
                freeze_message: __('Searching knowledge base...'),
                callback: function(r) {
                    if (r.message && r.message.success) {
                        let sources_html = '';
                        if (r.message.sources && r.message.sources.length > 0) {
                            sources_html = '<hr><h5>Sources</h5><ul>';
                            r.message.sources.forEach(s => {
                                sources_html += `<li>${s.source} (Page: ${s.page})</li>`;
                            });
                            sources_html += '</ul>';
                        }
                        
                        frappe.msgprint({
                            title: __('Answer'),
                            message: r.message.answer + sources_html,
                            wide: true
                        });
                    } else {
                        frappe.msgprint({
                            title: __('Error'),
                            message: r.message.error || __('An error occurred'),
                            indicator: 'red'
                        });
                    }
                }
            });
        }
    });
    
    d.show();
};

// =============================================================================
// QUICK ACTIONS
// =============================================================================

// Add to navbar
$(document).ready(function() {
    // Add AI Crews menu item if user has access
    if (frappe.boot.user.can_read.includes('Job Posting Request')) {
        // The menu will be added via hooks or custom script
    }
});

// Real-time event listeners
frappe.realtime.on('crew_complete', function(data) {
    frappe.show_alert({
        message: __('AI Crew task completed for {0}', [data.name]),
        indicator: data.success ? 'green' : 'red'
    });
});
