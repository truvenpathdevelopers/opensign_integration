"""
Custom CrewAI Tools for Frappe Integration
==========================================

These tools allow CrewAI agents to interact with Frappe/ERPNext data.
"""

import frappe
from typing import Any, Type, Optional
from pydantic import BaseModel, Field

try:
    from crewai.tools import BaseTool
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    BaseTool = object


# =============================================================================
# FRAPPE DOCUMENT TOOL
# =============================================================================

class FrappeDocInput(BaseModel):
    """Input schema for FrappeDocTool."""
    doctype: str = Field(description="The DocType to query (e.g., 'Employee', 'Job Applicant')")
    name: Optional[str] = Field(default=None, description="Specific document name to fetch")
    filters: Optional[dict] = Field(default=None, description="Filters for listing documents")
    fields: Optional[list] = Field(default=None, description="Fields to retrieve")
    limit: int = Field(default=10, description="Maximum number of documents to return")


class FrappeDocTool(BaseTool if CREWAI_AVAILABLE else object):
    """
    Tool for fetching documents from Frappe/ERPNext.
    
    Allows agents to retrieve employee data, job applicants, and other
    HR-related documents from the ERP system.
    """
    
    name: str = "frappe_document_tool"
    description: str = """
    Fetch documents from Frappe/ERPNext database. 
    Use this tool to get employee data, job applicants, company information,
    and other relevant HR documents.
    
    Examples:
    - Get all employees: doctype='Employee', limit=50
    - Get specific employee: doctype='Employee', name='EMP-0001'
    - Get job applicants: doctype='Job Applicant', filters={'status': 'Open'}
    """
    args_schema: Type[BaseModel] = FrappeDocInput
    
    def _run(
        self,
        doctype: str,
        name: Optional[str] = None,
        filters: Optional[dict] = None,
        fields: Optional[list] = None,
        limit: int = 10
    ) -> str:
        """Execute the tool."""
        try:
            if name:
                # Fetch single document
                doc = frappe.get_doc(doctype, name)
                return doc.as_json()
            else:
                # Fetch list of documents
                docs = frappe.get_all(
                    doctype,
                    filters=filters or {},
                    fields=fields or ["name", "modified"],
                    limit_page_length=limit
                )
                return str(docs)
        except Exception as e:
            return f"Error fetching documents: {str(e)}"


# =============================================================================
# FRAPPE SEARCH TOOL
# =============================================================================

class FrappeSearchInput(BaseModel):
    """Input schema for FrappeSearchTool."""
    query: str = Field(description="Search query text")
    doctype: Optional[str] = Field(default=None, description="Limit search to specific DocType")
    limit: int = Field(default=20, description="Maximum results to return")


class FrappeSearchTool(BaseTool if CREWAI_AVAILABLE else object):
    """
    Tool for searching across Frappe/ERPNext documents.
    
    Performs full-text search across the database to find relevant
    employees, applicants, or other documents.
    """
    
    name: str = "frappe_search_tool"
    description: str = """
    Search across Frappe/ERPNext documents using full-text search.
    
    Examples:
    - Search for Python developers: query='Python developer'
    - Search employees named John: query='John', doctype='Employee'
    """
    args_schema: Type[BaseModel] = FrappeSearchInput
    
    def _run(
        self,
        query: str,
        doctype: Optional[str] = None,
        limit: int = 20
    ) -> str:
        """Execute the search."""
        try:
            from frappe.utils.global_search import search
            
            results = search(
                query,
                doctype=doctype,
                limit=limit
            )
            
            return str(results)
        except Exception as e:
            return f"Error searching: {str(e)}"


# =============================================================================
# FRAPPE FILE TOOL
# =============================================================================

class FrappeFileInput(BaseModel):
    """Input schema for FrappeFileTool."""
    file_url: str = Field(description="URL or path to the file")
    extract_text: bool = Field(default=True, description="Whether to extract text from PDFs")


class FrappeFileTool(BaseTool if CREWAI_AVAILABLE else object):
    """
    Tool for reading files attached to Frappe documents.
    
    Can extract text from PDFs, read text files, and access
    attached documents.
    """
    
    name: str = "frappe_file_tool"
    description: str = """
    Read and extract content from files in Frappe/ERPNext.
    Supports PDFs, text files, and other document formats.
    
    Examples:
    - Read a CV: file_url='/files/resume.pdf'
    """
    args_schema: Type[BaseModel] = FrappeFileInput
    
    def _run(
        self,
        file_url: str,
        extract_text: bool = True
    ) -> str:
        """Read the file."""
        import os
        
        try:
            # Get absolute file path
            if file_url.startswith("/files/"):
                file_path = frappe.get_site_path("public", file_url.lstrip("/"))
            elif file_url.startswith("/private/"):
                file_path = frappe.get_site_path(file_url.lstrip("/"))
            else:
                file_path = frappe.get_site_path("public", "files", file_url)
            
            if not os.path.exists(file_path):
                return f"File not found: {file_url}"
            
            # Handle PDFs
            if file_path.lower().endswith(".pdf") and extract_text:
                try:
                    from pypdf import PdfReader
                    reader = PdfReader(file_path)
                    text = ""
                    for page in reader.pages:
                        text += page.extract_text() + "\n"
                    return text
                except Exception as e:
                    return f"Error extracting PDF text: {str(e)}"
            
            # Handle text files
            elif file_path.lower().endswith((".txt", ".md", ".csv")):
                with open(file_path, "r", encoding="utf-8") as f:
                    return f.read()
            
            # Handle Word documents
            elif file_path.lower().endswith(".docx"):
                try:
                    from docx import Document
                    doc = Document(file_path)
                    return "\n".join([para.text for para in doc.paragraphs])
                except Exception as e:
                    return f"Error reading DOCX: {str(e)}"
            
            else:
                return f"Unsupported file type: {file_url}"
                
        except Exception as e:
            return f"Error reading file: {str(e)}"


# =============================================================================
# EMPLOYEE DATA TOOL
# =============================================================================

class EmployeeDataInput(BaseModel):
    """Input schema for EmployeeDataTool."""
    department: Optional[str] = Field(default=None, description="Filter by department")
    designation: Optional[str] = Field(default=None, description="Filter by designation")
    status: str = Field(default="Active", description="Employee status filter")
    include_skills: bool = Field(default=False, description="Include employee skills")


class EmployeeDataTool(BaseTool if CREWAI_AVAILABLE else object):
    """
    Tool specifically for retrieving employee data from ERPNext HR module.
    """
    
    name: str = "employee_data_tool"
    description: str = """
    Get detailed employee information from ERPNext HR module.
    Can filter by department, designation, and status.
    
    Examples:
    - Get all active employees: status='Active'
    - Get Engineering team: department='Engineering'
    """
    args_schema: Type[BaseModel] = EmployeeDataInput
    
    def _run(
        self,
        department: Optional[str] = None,
        designation: Optional[str] = None,
        status: str = "Active",
        include_skills: bool = False
    ) -> str:
        """Get employee data."""
        try:
            filters = {"status": status}
            if department:
                filters["department"] = department
            if designation:
                filters["designation"] = designation
            
            employees = frappe.get_all(
                "Employee",
                filters=filters,
                fields=[
                    "name", "employee_name", "designation", "department",
                    "date_of_joining", "reports_to", "company_email"
                ],
                limit_page_length=100
            )
            
            if include_skills:
                for emp in employees:
                    skills = frappe.get_all(
                        "Employee Skill",
                        filters={"parent": emp["name"]},
                        fields=["skill", "proficiency"]
                    )
                    emp["skills"] = skills
            
            return str(employees)
        except Exception as e:
            return f"Error fetching employees: {str(e)}"


# =============================================================================
# JOB APPLICANT TOOL
# =============================================================================

class JobApplicantInput(BaseModel):
    """Input schema for JobApplicantTool."""
    job_title: Optional[str] = Field(default=None, description="Filter by job opening")
    status: Optional[str] = Field(default=None, description="Applicant status")
    include_resume: bool = Field(default=False, description="Include resume content")


class JobApplicantTool(BaseTool if CREWAI_AVAILABLE else object):
    """
    Tool for retrieving job applicant data from ERPNext.
    """
    
    name: str = "job_applicant_tool"
    description: str = """
    Get job applicant information from ERPNext recruitment module.
    
    Examples:
    - Get all open applications: status='Open'
    - Get applicants for specific job: job_title='Software Engineer'
    """
    args_schema: Type[BaseModel] = JobApplicantInput
    
    def _run(
        self,
        job_title: Optional[str] = None,
        status: Optional[str] = None,
        include_resume: bool = False
    ) -> str:
        """Get job applicant data."""
        try:
            filters = {}
            if job_title:
                filters["job_title"] = ["like", f"%{job_title}%"]
            if status:
                filters["status"] = status
            
            applicants = frappe.get_all(
                "Job Applicant",
                filters=filters,
                fields=[
                    "name", "applicant_name", "email_id", "job_title",
                    "status", "rating", "resume_attachment"
                ],
                limit_page_length=50
            )
            
            if include_resume:
                file_tool = FrappeFileTool()
                for app in applicants:
                    if app.get("resume_attachment"):
                        app["resume_content"] = file_tool._run(
                            app["resume_attachment"]
                        )[:5000]  # Limit content size
            
            return str(applicants)
        except Exception as e:
            return f"Error fetching applicants: {str(e)}"
