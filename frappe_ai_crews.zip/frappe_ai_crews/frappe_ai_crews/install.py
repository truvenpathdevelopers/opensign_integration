"""
Post-install setup for Frappe AI Crews
"""

import frappe
from frappe import _


def after_install():
    """Run after app installation."""
    create_module_def()
    create_workspace()
    print("Frappe AI Crews installed successfully!")
    print("\nNext steps:")
    print("1. Go to AI Crew Settings and configure your API keys")
    print("2. Install Python dependencies: pip install crewai crewai-tools langchain chromadb")
    print("3. Create your first Job Posting Request or Knowledge Base")


def create_module_def():
    """Create Module Def if it doesn't exist."""
    if not frappe.db.exists("Module Def", "AI Crews"):
        doc = frappe.get_doc({
            "doctype": "Module Def",
            "module_name": "AI Crews",
            "app_name": "frappe_ai_crews"
        })
        doc.insert(ignore_permissions=True)
        frappe.db.commit()


def create_workspace():
    """Create workspace for AI Crews."""
    if frappe.db.exists("Workspace", "AI Crews"):
        return
    
    workspace = frappe.get_doc({
        "doctype": "Workspace",
        "name": "AI Crews",
        "label": "AI Crews",
        "module": "AI Crews",
        "icon": "robot",
        "indicator_color": "purple",
        "is_standard": 1,
        "public": 1,
        "content": """[
            {
                "type": "header",
                "data": {
                    "text": "<span class=\\"h4\\"><b>AI-Powered HR & Knowledge Management</b></span>",
                    "col": 12
                }
            },
            {
                "type": "paragraph",
                "data": {
                    "text": "Multi-agent AI system for job postings, recruitment, profile matching, and knowledge base Q&A.",
                    "col": 12
                }
            },
            {
                "type": "spacer",
                "data": {
                    "col": 12
                }
            },
            {
                "type": "header",
                "data": {
                    "text": "<span class=\\"h5\\">Quick Actions</span>",
                    "col": 12
                }
            },
            {
                "type": "shortcut",
                "data": {
                    "shortcut_name": "Job Posting Request",
                    "col": 4
                }
            },
            {
                "type": "shortcut",
                "data": {
                    "shortcut_name": "Recruitment Request",
                    "col": 4
                }
            },
            {
                "type": "shortcut",
                "data": {
                    "shortcut_name": "Profile Match Request",
                    "col": 4
                }
            },
            {
                "type": "spacer",
                "data": {
                    "col": 12
                }
            },
            {
                "type": "header",
                "data": {
                    "text": "<span class=\\"h5\\">Knowledge Base</span>",
                    "col": 12
                }
            },
            {
                "type": "shortcut",
                "data": {
                    "shortcut_name": "Knowledge Base",
                    "col": 4
                }
            },
            {
                "type": "shortcut",
                "data": {
                    "shortcut_name": "Knowledge Query",
                    "col": 4
                }
            },
            {
                "type": "spacer",
                "data": {
                    "col": 12
                }
            },
            {
                "type": "header",
                "data": {
                    "text": "<span class=\\"h5\\">Settings</span>",
                    "col": 12
                }
            },
            {
                "type": "shortcut",
                "data": {
                    "shortcut_name": "AI Crew Settings",
                    "col": 4
                }
            }
        ]""",
        "shortcuts": [
            {
                "label": "Job Posting Request",
                "link_to": "Job Posting Request",
                "type": "DocType",
                "color": "Blue"
            },
            {
                "label": "Recruitment Request",
                "link_to": "Recruitment Request",
                "type": "DocType",
                "color": "Green"
            },
            {
                "label": "Profile Match Request",
                "link_to": "Profile Match Request",
                "type": "DocType",
                "color": "Orange"
            },
            {
                "label": "Knowledge Base",
                "link_to": "Knowledge Base",
                "type": "DocType",
                "color": "Purple"
            },
            {
                "label": "Knowledge Query",
                "link_to": "Knowledge Query",
                "type": "DocType",
                "color": "Cyan"
            },
            {
                "label": "AI Crew Settings",
                "link_to": "AI Crew Settings",
                "type": "DocType",
                "color": "Grey"
            }
        ]
    })
    
    try:
        workspace.insert(ignore_permissions=True)
        frappe.db.commit()
    except Exception as e:
        print(f"Warning: Could not create workspace: {e}")


def before_uninstall():
    """Clean up before uninstall."""
    # Optionally remove workspace
    if frappe.db.exists("Workspace", "AI Crews"):
        frappe.delete_doc("Workspace", "AI Crews", force=True)
