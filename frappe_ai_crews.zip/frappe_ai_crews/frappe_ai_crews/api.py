"""
Frappe AI Crews - Public API
============================

This module exposes all public API methods for the AI Crews app.
"""

import frappe
from frappe import _


# =============================================================================
# JOB POSTING API
# =============================================================================

@frappe.whitelist()
def generate_job_posting(**kwargs):
    """Generate a job posting using AI."""
    from frappe_ai_crews.crews.job_posting import generate_job_posting as _generate
    return _generate(**kwargs)


@frappe.whitelist()
def generate_job_posting_async(request_name):
    """Queue job posting generation."""
    from frappe_ai_crews.crews.job_posting import generate_job_posting_async as _generate_async
    return _generate_async(request_name)


# =============================================================================
# RECRUITMENT API
# =============================================================================

@frappe.whitelist()
def run_recruitment(**kwargs):
    """Run recruitment process using AI."""
    from frappe_ai_crews.crews.recruitment import run_recruitment as _run
    return _run(**kwargs)


@frappe.whitelist()
def run_recruitment_async(request_name):
    """Queue recruitment process."""
    from frappe_ai_crews.crews.recruitment import run_recruitment_async as _run_async
    return _run_async(request_name)


# =============================================================================
# PROFILE MATCHING API
# =============================================================================

@frappe.whitelist()
def match_profile_to_job(**kwargs):
    """Match a profile to a job using AI."""
    from frappe_ai_crews.crews.match_profile import match_profile_to_job as _match
    return _match(**kwargs)


@frappe.whitelist()
def match_profile_async(request_name):
    """Queue profile matching."""
    from frappe_ai_crews.crews.match_profile import match_profile_async as _match_async
    return _match_async(request_name)


@frappe.whitelist()
def batch_match_profiles(**kwargs):
    """Match multiple profiles to a job."""
    from frappe_ai_crews.crews.match_profile import batch_match_profiles as _batch
    return _batch(**kwargs)


# =============================================================================
# KNOWLEDGE BASE API
# =============================================================================

@frappe.whitelist()
def create_knowledge_base(name, description=""):
    """Create a new knowledge base."""
    from frappe_ai_crews.crews.meta_quest import create_knowledge_base as _create
    return _create(name, description)


@frappe.whitelist()
def add_documents_to_kb(kb_name, file_urls):
    """Add documents to a knowledge base."""
    from frappe_ai_crews.crews.meta_quest import add_documents_to_kb as _add
    return _add(kb_name, file_urls)


@frappe.whitelist()
def query_knowledge_base(question, knowledge_base_name):
    """Query a knowledge base."""
    from frappe_ai_crews.crews.meta_quest import query_knowledge_base as _query
    return _query(question, knowledge_base_name)


@frappe.whitelist()
def query_knowledge_async(query_name):
    """Queue knowledge query."""
    from frappe_ai_crews.crews.meta_quest import query_knowledge_async as _query_async
    return _query_async(query_name)


@frappe.whitelist()
def simple_search(question, knowledge_base_name, k=5):
    """Simple semantic search in knowledge base."""
    from frappe_ai_crews.crews.meta_quest import simple_search as _search
    return _search(question, knowledge_base_name, k)


# =============================================================================
# UTILITY API
# =============================================================================

@frappe.whitelist()
def check_ai_status():
    """Check AI Crews status and configuration."""
    from frappe_ai_crews.crews.utils import check_ai_status as _check
    return _check()


@frappe.whitelist()
def get_available_crews():
    """Get list of available AI crews."""
    from frappe_ai_crews.crews.utils import get_available_crews as _get_crews
    return _get_crews()


@frappe.whitelist(allow_guest=True)
def get_version():
    """Get app version."""
    return {
        "app": "Frappe AI Crews",
        "version": "1.0.0",
        "description": "CrewAI Multi-Agent AI System for HR & Knowledge Management"
    }
